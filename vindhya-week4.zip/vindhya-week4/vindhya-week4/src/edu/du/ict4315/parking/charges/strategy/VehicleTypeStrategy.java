package edu.du.ict4315.parking.charges.strategy;

import java.time.LocalDateTime;


import edu.du.ict4315.currency.Money;
import edu.du.ict4315.parking.ParkingPermit;
import edu.du.ict4315.parking.Car;
import edu.du.ict4315.parking.CarType;
import edu.du.ict4315.parking.ParkingLot;

public class VehicleTypeStrategy implements ParkingChargeStrategy {

	/*
	 * subtract 15% if compact car
	 */
	@Override
	public Money getParkingCharges(ParkingLot lot, ParkingPermit p, LocalDateTime in) {
		Car car = p.getCar();
		Money money = lot.getBaseRate();
		if(car.getType() == CarType.COMPACT) {
			money = Money.times(money, 0.85);
		}
		
		return money;
	}

}
