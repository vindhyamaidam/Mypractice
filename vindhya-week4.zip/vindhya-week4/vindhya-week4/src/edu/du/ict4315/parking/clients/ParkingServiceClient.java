//////////////////////////
// This class represents a parking office client for "smoke test" use.
// The client is in the same JVM as the Parking Office
// File: ParkingOfficeClient.java
// Author: M. I. Schwartz
//////////////////////////
package edu.du.ict4315.parking.clients;

import java.time.LocalDateTime;

import edu.du.ict4315.parking.Address;
import edu.du.ict4315.parking.Car;
import edu.du.ict4315.parking.CarType;
import edu.du.ict4315.parking.Customer;
import edu.du.ict4315.parking.ParkingLot;
import edu.du.ict4315.parking.ParkingPermit;
import edu.du.ict4315.parking.ParkingTransaction;
import edu.du.ict4315.parking.RealParkingOffice;
import edu.du.ict4315.parking.service.ParkingService;

public class ParkingServiceClient {
	public static void main(String[] args) {
		RealParkingOffice office = new RealParkingOffice();
		office.setParkingOfficeName("DU Parking Office");
		office.setParkingOfficeAddress(
				new Address.Builder().withStreetAddress1("2130 S. High St.")
				                     .withCity("Denver")
				                     .withState("CO")
				                     .withZip("80208")
				                     .build()
				);
		
		
		
		ParkingService parkingService = new ParkingService(office);
		
		
		
		sampleTransactions(parkingService);
		System.out.println(office);
	}
	
  // Ths sampleTransactions method can be augmented to include whatever tests you like.
	public static void sampleTransactions(ParkingService parkingService) {
		/*
		// Use case: Add a customer
		Address address = new Address.Builder()
            .withStreetAddress1("123 Elm St.")
            .withCity("Denver")
            .withState("CO")
            .withZip("80201")
            .build();
		Customer customer = new Customer("C123","Joan","Public","303-555-1212",address);
		
		// Use case: Register Customer
		String customerId = parkingService.register(customer);
		System.out.println("Registered Joan Public: "+customerId);
		
		// Use case: Give customer a car
		Car car1 = new Car(CarType.COMPACT,"ABC123",customer);
		Car car2 = new Car();
		car2.setType(CarType.SUV);
		car2.setLicensePlate("XYZ987");
		car2.setOwner(customer);
		
		// Use Case: Register Car
		String permit1 = parkingService.register(car1);
		String permit2 = parkingService.register(car2);
		
		System.out.println("Permit: "+parkingService.getParkingPermit(permit1));
		System.out.println("Permit: "+parkingService.getParkingPermit(permit2));

		// Park in Lot W
		ParkingLot lot = parkingService.getParkingLot("W");
		System.out.println("Lot: "+lot);
		*/
		
		
		String customerId = parkingService.performCommand("CUSTOMER", new String[]{"Adam"});
		System.out.println("Registered Adam: "+customerId);
		
		String carId = parkingService.performCommand("CAR", new String[] {"ABC678", "CUST-12"});
		System.out.println("car registered: " + carId);
		
		String park = parkingService.performCommand("PARK", new String[] {"108", "P1001", ""});
		System.out.println("park registered: " + park);
	            
		String charges = parkingService.performCommand("CHARGES", new String[] {"CUST-12"});
		System.out.println("charges for adam : " + charges);
		
	}
}
