////////////////////
// This class represents the Parking Lot
// File: ParkingLot.java
// Author: M. I. Schwartz
////////////////////
package edu.du.ict4315.parking;

import edu.du.ict4315.currency.Money;
import edu.du.ict4315.parking.charges.factory.ParkingChargeStrategyFactory;
import edu.du.ict4315.parking.charges.strategy.ParkingChargeStrategy;

import java.time.LocalDateTime;

public class ParkingLot {
    private String id;
    private String name;
    private Address address;
    private Money baseRate = Money.of(5.00);
    
    private ParkingChargeStrategy parkingChargeStrategy;
    
    public ParkingLot(String id, String name, Address address) {
    	this.id = id;
    	this.name = name;
    	this.address = address;
    }
    
    public ParkingLot(String id, String name, Address address, Money baseRate) {
      this.id = id;
      this.name = name;
      this.address = address;
      this.baseRate = baseRate;
      
    }
    
    /*
     * given a factory, create a strategy out of it
     */
    public void assignParkingChargeStrategy(ParkingChargeStrategyFactory factory) {
    	if(factory == null)
    		return;
    	ParkingChargeStrategy strategy = factory.makeStrategy();
    	setParkingChargeStrategy(strategy);
    }
    
    public Money getParkingCharges(ParkingPermit p, LocalDateTime in) {
      return 
    	parkingChargeStrategy != null ?
    	  parkingChargeStrategy.getParkingCharges(this, p, in) :
    	  baseRate;
    }
    
    public Money getBaseRate() {
    	return baseRate;
    }
    
    public String toString() {
    	StringBuilder sb = new StringBuilder();

    	sb.append(id);
    	sb.append("\n");
    	sb.append(name);
    	sb.append("\n");
    	sb.append(address);

    	return sb.toString();
    }

	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public Address getAddress() {
		return address;
	}
	
  // Method for permit-required-on-enter lot
  public void enterLot(LocalDateTime in, String permitId) {
  }

	// Method for permit-required-on-exit lot
  public void exitLot(LocalDateTime in, LocalDateTime out, String permitId) {
  }

public ParkingChargeStrategy getParkingChargeStrategy() {
	return parkingChargeStrategy;
}

public void setParkingChargeStrategy(ParkingChargeStrategy parkingChargeStrategy) {
	this.parkingChargeStrategy = parkingChargeStrategy;
}


  
}
