package edu.du.ict4315.parking.charges.strategy;

import java.time.DayOfWeek;
import java.time.LocalDateTime;

import edu.du.ict4315.currency.Money;
import edu.du.ict4315.parking.CarType;
import edu.du.ict4315.parking.ParkingLot;
import edu.du.ict4315.parking.ParkingPermit;

public class WeekendStrategy implements ParkingChargeStrategy {

	/*
	 * subtract 25% if weekend
	 */
	@Override
	public Money getParkingCharges(ParkingLot lot, ParkingPermit p, LocalDateTime in) {
		Money money = lot.getBaseRate();
		if(in.getDayOfWeek() == DayOfWeek.SUNDAY ||
				in.getDayOfWeek() == DayOfWeek.SATURDAY) {
			money = Money.times(money, 0.75);
		}
		
		return money;
	}

}
