package edu.du.ict4315.parking.charges.strategy;

import java.time.LocalDateTime;

import edu.du.ict4315.currency.Money;
import edu.du.ict4315.parking.ParkingLot;
import edu.du.ict4315.parking.ParkingPermit;

public interface ParkingChargeStrategy {
	public Money getParkingCharges(ParkingLot lot, ParkingPermit p, LocalDateTime in);	    
}
