////////////////////
// This enum represents car types with different policies in the Parking System
// File: CarType.java
// Author: M. I. Schwartz
////////////////////
package edu.du.ict4315.parking;

public enum CarType {
	COMPACT, SUV
}
