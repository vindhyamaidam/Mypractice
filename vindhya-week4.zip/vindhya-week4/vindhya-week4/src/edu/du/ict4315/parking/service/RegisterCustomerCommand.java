package edu.du.ict4315.parking.service;

import java.util.Properties;

import edu.du.ict4315.parking.Customer;
import edu.du.ict4315.parking.RealParkingOffice;

public class RegisterCustomerCommand implements Command {

	private RealParkingOffice office;
	
	@Override
	public String getCommandName() {
		
		return "CUSTOMER";
	}

	@Override
	public String getDisplayName() {
		
		return "register a customer";
	}

	@Override
	public String execute(Properties params) {
		try {
			checkParameters(params);
		} catch(Exception ex) {
			return ex.getMessage();
		}
		
		Customer customer = new Customer();
        customer.setLastName(params.getProperty("name"));
        
        return office.register(customer);
	}
	
	private void checkParameters(Properties params) throws Exception {
		if(!params.containsKey("name"))
			throw new Exception("customer name missing");
		if(params.getProperty("name") == null || params.getProperty("name").isEmpty())
			throw new Exception("customer name is empty");
		RealParkingOffice office = (RealParkingOffice) params.get("office");
					
	}

	public RealParkingOffice getOffice() {
		return office;
	}

	public void setOffice(RealParkingOffice office) {
		this.office = office;
	}

}
