package edu.du.ict4315.parking.charges.factory;

import edu.du.ict4315.parking.charges.strategy.ParkingChargeStrategy;
import edu.du.ict4315.parking.charges.strategy.VehicleTypeStrategy;

/*
 * a factory class that generates vehicleTypeStrategy
 */
public class VehicleTypeFactory implements ParkingChargeStrategyFactory {

	@Override
	public ParkingChargeStrategy makeStrategy() {
		VehicleTypeStrategy vehicleTypeStrategy = new VehicleTypeStrategy();
		return vehicleTypeStrategy;
	}

}
