package edu.du.ict4315.parking.service;

import java.util.Properties;

import edu.du.ict4315.parking.Car;
import edu.du.ict4315.parking.RealParkingOffice;

public class RegisterCarCommand implements Command {

	private RealParkingOffice office;
	
	@Override
	public String getCommandName() {
		return "CAR";
	}

	@Override
	public String getDisplayName() {
		return "register car";
	}

	@Override
	public String execute(Properties params) {
		try {
			checkParameters(params);
		} catch(Exception ex) {
			return ex.getMessage();
		}
		
		Car car = (Car) params.get("car");
        
        return office.register(car);
	}
	
	private void checkParameters(Properties params) throws Exception {
		if(!params.containsKey("car"))
			throw new Exception("Car is missing");
	}

	public RealParkingOffice getOffice() {
		return office;
	}

	public void setOffice(RealParkingOffice office) {
		this.office = office;
	}

}
