package edu.du.ict4315.parking.charges.factory;

import edu.du.ict4315.parking.charges.strategy.ParkingChargeStrategy;
import edu.du.ict4315.parking.charges.strategy.WeekendStrategy;

/*
 * factory that creates weekendStrategy object
 */
public class WeekendFactory implements ParkingChargeStrategyFactory {

	@Override
	public ParkingChargeStrategy makeStrategy() {
		WeekendStrategy weekendStrategy = new WeekendStrategy();
		return weekendStrategy;
	}

}
